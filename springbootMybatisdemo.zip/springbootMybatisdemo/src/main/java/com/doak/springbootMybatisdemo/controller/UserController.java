package com.doak.springbootMybatisdemo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.doak.logbackPrjDemo.controller.UserController;
import com.doak.springbootMybatisdemo.entity.User;
import com.doak.springbootMybatisdemo.service.UserService;

@Controller
@RequestMapping(value="/user")
public class UserController {
	private static final Logger  logger  = LoggerFactory.getLogger(UserController.class);

	@Autowired
	UserService userService;
	
	@RequestMapping(value="/login")
	public String dologin(){
		return "login";
	}
	@RequestMapping(value="/register")
	public String doregister(){
		return "register";
	}
	
	
	@RequestMapping(value="/dologin")
	public String login(User user, Model model){
		
		User user1 = userService.selectUser(user);
		
		if(user1 == null){
			model.addAttribute("msg", "用户名或者密码错误！！");
			logger.error("用户名或者密码错误");
			return "fail";
			
		}else {
			model.addAttribute("msg", "登录成功！！！");
			logger.info("登陆成功");
			return "success";
		}
		
	}
	@RequestMapping(value="/doregister")
	public String register(User user, Model model){
		int insertUser = userService.interUser(user);
		if(insertUser==1){
			model.addAttribute("msg", "注册成功");
			logger.info("注册成功");
			return "login";
		}else{
			model.addAttribute("msg", "注册失败");
			logger.error("注册失败");
			return "fail";
		}
		
		
	}

}
